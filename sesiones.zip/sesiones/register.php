<?php
include("header.html");
?>
    <h2>Registro de usuarios</h2>









<?php
include("footer.html");
?>