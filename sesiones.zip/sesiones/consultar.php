<?php
include("header.html");
require("config.php");

echo "<h2 class='text-center mt-5'>Listado de pedidos - consultar</h2>";
?>
<table class="table table-dark table-striped text-center">
    <tr>
        <th scope="col">ID</th>
        <th scope="col">Fecha pedidos</th>
        <th scope="col">Pedidos</th>
        <th scope="col">Unidades</th>
        <th scope="col">Actualizar</th>
        <th scope="col">Eliminar</th>
    </tr>

<?php
try {
    foreach($conn->query('SELECT * from pedidos') as $row) {
        echo '<tr><td>'.$row['id'].'</td>';
        echo '<td>'.$row['fecha_pedido'].'</td>.';
        echo '<td>'.$row['producto'].'</td>.';
        echo '<td>'.$row['unidades'].'</td>.';
        echo '<td><a href="actualizar.php?codigo='.$row["id"].'"><ion-icon name="trash-bin-outline"></ion-icon></a></td>';
        echo '<td><a href="eliminar.php?codigo='.$row["id"].'"><ion-icon name="trash-bin-outline"></ion-icon></a></td></tr>';
    }
    $conn = null;
} catch (PDOException $e) {
    print "Error!: " . $e->getMessage() . "<br/>";
    die();
}
?>
</table>

<?php
include("footer.html");
?>