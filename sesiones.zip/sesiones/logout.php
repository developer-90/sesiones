<?php
include("header.html");
?>
    <h2>Logout</h2>









<?php
include("footer.html");
?>